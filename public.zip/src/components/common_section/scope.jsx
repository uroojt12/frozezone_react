import React from "react";
const Scope = ({ data }) => {
  return (
    <>
      <section id="sec_scope">
        <div class="shape">
          <img src={data.image_1} alt="" />
        </div>
        <div class="overlay"></div>
        <div class="contain">
          <div class="inner">
            <div class="sec_heading">
              <h5>{data.title}</h5>
              <h2>{data.heading}</h2>
            </div>
            <div class="cta btn-box ">
              <a href={data.btn_link_01} class="webBtn colorBtn theme-btn-one">
                {data.btn_01}
              </a>
            </div>
          </div>
        </div>
        <div class="image-s">
          <img src={data.image_2} alt="" />
        </div>
        <div class="b-shape">
          <img src={data.image_3} alt="" />
        </div>
      </section>
    </>
  );
};
export default Scope;
