import React from "react";
const Habout = ({ data }) => {
  return (
    <>
      <section id="sec_about">
        <div class="contain">
          <div class="flex">
            <div class="col col1">
              <div class="image">
                <img src={data.image_b} alt="" />
              </div>
            </div>
            <div class="col col2">
              <div class="inner">
                <div class="sec_heading">
                  <h5>{data.title}</h5>
                  <h2>{data.heading}</h2>
                </div>
                <div class="content">
                  <p>{data.para_1}</p>
                  <p>{data.para_2}</p>
                </div>
                <div class="cta btn-box ">
                  <a
                    href={data.btn_link_01}
                    class="webBtn colorBtn theme-btn-one"
                  >
                    {data.btn_01}
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Habout;
