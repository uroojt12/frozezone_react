import React from "react";
import FindLst from "./sections/findLst";
const Find = ({ data }) => {
  return (
    <>
      <section id="sec_find">
        <div class="contain">
          <div class="sec_heading">
            <h5>{data.title}</h5>
            <h2>{data.heading}</h2>
          </div>
          <div class="flex">
            {data.block.map((val) => {
              return <FindLst val={val} />;
            })}
          </div>
        </div>
      </section>
    </>
  );
};
export default Find;
