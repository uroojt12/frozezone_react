import React from "react";

const CatLst = ({ val }) => {
  return (
    <div class="flex">
      <div class="col col1">
        <div class="inner">
          <div class="sec_heading">
            <h2>{val.heading}</h2>
          </div>
          <div class="content">
            <p>{val.para}</p>
            <ul class="list_it">
              <li>onsite catering</li>
              <li>custom ice cream cakes</li>
              <li>dairy-free options</li>
              <li>housemade waffle cones &amp; sauces </li>
              <li>over 30 flavors to choose from!</li>
            </ul>
            <div class="cta btn-box ">
              <a href="about.php" class="webBtn colorBtn theme-btn-one">
                {val.btn}
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="col col2">
        <div class="image">
          <img src={val?.image} alt="" />
        </div>
      </div>
    </div>
  );
};

export default CatLst;
