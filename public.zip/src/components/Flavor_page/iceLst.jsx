import React from "react";

const IceLst = ({ val }) => {
  return (
    <div className="inner">
      <div class="image">
        <img src={val.image} alt="" />
        <div class="inside">
          <div class="detail">
            <h3>{val.sub_heading}</h3>
            <p>{val.para}</p>
          </div>
          <div class="add">
            <a href="?">
              <img src={val.add} alt="" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IceLst;
