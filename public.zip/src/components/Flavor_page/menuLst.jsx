import React from "react";

const IceLst = ({ val }) => {
  return (
    <div class="faqBlk active">
      <h5>Icecream</h5>
      <div class="txt">
        <div class="image">
          <img src="images/sub-3.png" alt="" />
        </div>
        <div class="cntnt">
          <div class="price">
            <div class="head">
              <h6>Vanilla</h6>
            </div>
            <div class="line-1"></div>
            <div class="foot">
              <p>
                <strong>$12</strong>
              </p>
            </div>
          </div>
          <p>
            Lorem ipsum dolor sit amet, feugiat delicata Lorem ipsum dolor sit
            amet, feugiat delicata.
          </p>
        </div>
      </div>
      <div class="txt">
        <div class="image">
          <img src="images/scope-2.png" alt="" />
        </div>
        <div class="cntnt">
          <div class="price">
            <div class="head">
              <h6>Strawberry</h6>
            </div>
            <div class="line-1"></div>
            <div class="foot">
              <p>
                <strong>$14</strong>
              </p>
            </div>
          </div>
          <p>
            Lorem ipsum dolor sit amet, feugiat delicata Lorem ipsum dolor sit
            amet, feugiat delicata.
          </p>
        </div>
      </div>
      <div class="txt">
        <div class="image">
          <img src="images/t-1.png" alt="" />
        </div>
        <div class="cntnt">
          <div class="price">
            <div class="head">
              <h6>Chocolate</h6>
            </div>
            <div class="line-1"></div>
            <div class="foot">
              <p>
                <strong>$15</strong>
              </p>
            </div>
          </div>
          <p>
            Lorem ipsum dolor sit amet, feugiat delicata Lorem ipsum dolor sit
            amet, feugiat delicata.
          </p>
        </div>
      </div>
      <div class="txt">
        <div class="image">
          <img src="images/ice4.png" alt="" />
        </div>
        <div class="cntnt">
          <div class="price">
            <div class="head">
              <h6>Mint </h6>
            </div>
            <div class="line-1"></div>
            <div class="foot">
              <p>
                <strong>$16</strong>
              </p>
            </div>
          </div>
          <p>
            Lorem ipsum dolor sit amet, feugiat delicata Lorem ipsum dolor sit
            amet, feugiat delicata.
          </p>
        </div>
      </div>
    </div>
  );
};

export default IceLst;
